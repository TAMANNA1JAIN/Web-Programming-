document.addEventListener("DOMContentLoaded", () => {
  const isLoggedIn = localStorage.getItem("loggedIn") === "true"
  const currentPage = window.location.pathname.split("/").pop()

  if (!isLoggedIn && (currentPage === "details.html" || currentPage === "profile.html")) {
    window.location.href = "index.html"
    return
  }

  const loginForm = document.getElementById("loginForm")
  const detailsForm = document.getElementById("detailsForm")
  const profileInfo = document.getElementById("profileInfo")
  const actionButton = document.getElementById("actionButton")

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault()
      const name = document.getElementById("name").value
      const password = document.getElementById("password").value

      if (name === "admin" && password === "password") {
        localStorage.setItem("loggedIn", "true")
        window.location.href = "details.html"
      } else {
        document.getElementById("error").textContent = "Invalid credentials"
      }
    })
  }

  if (detailsForm) {
    const savedDetails = JSON.parse(localStorage.getItem("userDetails") || "{}")
    Object.keys(savedDetails).forEach((key) => {
      const input = document.getElementById(key)
      if (input) input.value = savedDetails[key]
    })

    detailsForm.addEventListener("submit", (e) => {
      e.preventDefault()
      const formData = new FormData(detailsForm)
      const details = Object.fromEntries(formData.entries())
      localStorage.setItem("userDetails", JSON.stringify(details))
      window.location.href = "profile.html"
    })
  }

  if (actionButton) {
    actionButton.addEventListener("click", () => {
      alert("Action button clicked! Add your desired functionality here.")
    })
  }

  // Update profile page display
  const profileName = document.getElementById("profileName")
  const profileGender = document.getElementById("profileGender")
  const profileNumber = document.getElementById("profileNumber")
  const profileBirthdate = document.getElementById("profileBirthdate")
  const profileSociety = document.getElementById("profileSociety")

  if (profileName && profileGender && profileNumber && profileBirthdate && profileSociety) {
    const details = JSON.parse(localStorage.getItem("userDetails") || "{}")
    if (Object.keys(details).length > 0) {
      profileName.textContent = details.fullName || "Not provided"
      profileGender.textContent = details.gender || "Not provided"
      profileNumber.textContent = details.number || "Not provided"
      profileBirthdate.textContent = details.birthdate || "Not provided"
      profileSociety.textContent = details.society || "Not provided"
    }
  }
})

function logout() {
  localStorage.removeItem("loggedIn")
  localStorage.removeItem("userDetails")
  window.location.href = "index.html"
}

